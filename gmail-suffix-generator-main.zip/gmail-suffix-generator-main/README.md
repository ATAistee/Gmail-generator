# gmail-suffix-generator

A simple email generator that uses the [gmail aliases feature]( https://support.cloudhq.net/how-to-setup-gmail-aliases/#:~:text=Append%20a%20plus%20(“%2B”,at%20yourusername%40gmail.com. ) to generate unlimited email addresses which all point to one inbox.
This means u can create multiple accounts for a service while all trafic is pointed to one inbox which is usefull for mass creating accounts.

Be aware a small percentage of websites don't allow these types of email adresses. ( see table below )

WARNING⚠️: This isn't a Google account generator.

![](https://cdn.discordapp.com/attachments/916770878010839170/1094698142823366677/211336763-b56d307f-59cc-40cd-80e2-6db87ea211f8.png)

## How to use :

1.  download the repo

2.  open emailgen.py

3.  go into the "generate suffix" submenu

4.  input ur <u><mark>**gmail**</mark></u> address and select how many emails u want to generate

5.  the emails will be exported automatically to the "emailgen.py" directory (Output.txt).

## Working status:
**note: most meta products wont work**
| Status | Service       |
| - | ------ |
| 🚫| Facebook |
| 🚫| Instagram |   
| 🚫| Steam | 
| ✅| Discord |
